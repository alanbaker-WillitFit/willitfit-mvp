import { Airline } from "@/types";
import { getSheetRows, isLive, toNumber, slugify } from "./googleSheets";
import { FALLBACK_AIRLINES } from "@/data/fallback";

type AirlineRow = {
  AirlineID: string;
  AirlineName: string;
  Country: string;
  LogoURL: string;
  PersonalItemHeight: string;
  PersonalItemWidth: string;
  PersonalItemDepth: string;
  CabinHeight: string;
  CabinWidth: string;
  CabinDepth: string;
  WeightLimit: string;
  WebsiteURL: string;
  LastUpdated: string;
  Status: string;
};

function mapRow(row: AirlineRow): Airline {
  return {
    airlineId: row.AirlineID,
    airlineName: row.AirlineName,
    slug: slugify(row.AirlineName),
    country: row.Country,
    logoUrl: row.LogoURL,
    personalItem: {
      heightCm: toNumber(row.PersonalItemHeight),
      widthCm: toNumber(row.PersonalItemWidth),
      depthCm: toNumber(row.PersonalItemDepth),
    },
    cabinBag: {
      heightCm: toNumber(row.CabinHeight),
      widthCm: toNumber(row.CabinWidth),
      depthCm: toNumber(row.CabinDepth),
    },
    weightLimitKg: row.WeightLimit ? toNumber(row.WeightLimit, NaN) : null,
    websiteUrl: row.WebsiteURL,
    lastUpdated: row.LastUpdated,
    status: (row.Status as Airline["status"]) || "Draft",
  };
}

/**
 * Fetches and caches all "Live" airlines from the Sheet for the duration
 * of SHEET_REVALIDATE_SECONDS (Next.js fetch-level caching applies to the
 * underlying request; this function itself is request-deduped per render
 * via React's cache()-free memoization at the module level being avoided
 * intentionally so ISR/ on-demand revalidation stays in control).
 */
export async function getAirlines(): Promise<{ airlines: Airline[]; source: "sheet" | "fallback" }> {
  const rows = await getSheetRows<AirlineRow>("Airlines");

  if (!rows || rows.length === 0) {
    return { airlines: FALLBACK_AIRLINES, source: "fallback" };
  }

  const airlines = rows.map(mapRow).filter((a) => isLive(a.status) && a.airlineName);
  if (airlines.length === 0) {
    return { airlines: FALLBACK_AIRLINES, source: "fallback" };
  }

  return { airlines, source: "sheet" };
}

export async function getAirlineBySlug(
  slug: string
): Promise<{ airline: Airline | null; source: "sheet" | "fallback" }> {
  const { airlines, source } = await getAirlines();
  const airline = airlines.find((a) => a.slug === slug) ?? null;
  return { airline, source };
}

export async function getAllAirlineSlugs(): Promise<string[]> {
  const { airlines } = await getAirlines();
  return airlines.map((a) => a.slug);
}
